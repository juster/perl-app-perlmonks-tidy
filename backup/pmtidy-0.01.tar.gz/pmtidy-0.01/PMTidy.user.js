// PMTidy.user.js - PerlMonks Code Tidier
// Greasemonkey user script
// Version 0.1
// Oct 25, 2008
// by juster on PM
// -----------------------------------------------------------------------------
// Copyright (c) 2008 Justin Davis <jrcd83@gmail.com>
// Released under the Perl Artistic License.
// http://www.perlfoundation.org/legal/licenses/artistic-2_0.html
// -----------------------------------------------------------------------------
// Inspired by and started from Jon Allen's AJAX perl highlighter:
// Project website: http://perl.jonallen.info/projects/syntaxhighlighting
// -----------------------------------------------------------------------------
// ==UserScript==
// @name           PerlMonks Code Tidier
// @namespace      http://www.perlmonks.com/?node=juster
// @description    Highlights/reformats code blocks using AJAX and perl script.
// @include        http://www.perlmonks.com/*
// ==/UserScript==


// --CONFIGURATION-------------------------------------------------
// cgiurl   - The url of a Perl::Tidy cgi script.
// wordwrap - Wordwrap isn't very reliable yet, but you can try it.
TidyConfig          = new Object();
TidyConfig.cgiurl   = 'http://juster.info/perl/pmtidy/pmtidy.pl';
TidyConfig.wordwrap = 80;
// ----------------------------------------------------------------

                   // This must match the cgi script's message!
const UNPERLMSG  = "How very unperlish of you!";
const PMHVersion = "0.01";

// Insert the perltidy style classes.
GM_addStyle("\
.c  { color: #228B22;} /* comment */\n\
.cm { color: #000000;} /* comma */\n\
.co { color: #000000;} /* colon */\n\
.h  { color: #CD5555; font-weight:bold;} /* here-doc-target */\n\
.hh { color: #CD5555; font-style:italic;} /* here-doc-text */\n\
.i  { color: #00688B;} /* identifier */\n\
.j  { color: #CD5555; font-weight:bold;} /* label */\n\
.k  { color: #8B008B; font-weight:bold;} /* keyword */\n\
.m  { color: #FF0000; font-weight:bold;} /* subroutine */\n\
.n  { color: #B452CD;} /* numeric */\n\
.p  { color: #000000;} /* paren */\n\
.pd { color: #228B22; font-style:italic;} /* pod-text */\n\
.pu { color: #000000;} /* punctuation */\n\
.q  { color: #CD5555;} /* quote */\n\
.s  { color: #000000;} /* structure */\n\
.sc { color: #000000;} /* semicolon */\n\
.v  { color: #B452CD;} /* v-string */\n\
.w  { color: #000000;} /* bareword */\n\
");


function TidyCode(pElem) {
  // codeElem should be the <p class="code"> tag element
  // private
  var highlight = false;
  var tidy      = false;
  var self      = this;
  var codeElem  = PerlSyntax.findElements(pElem, 'tt', 'codetext')[0];
  var dlElem    = PerlSyntax.findElements(pElem, 'span', 'embed-code-dl')[0];
  var linkElems = new Array;
  var origCodeHTML  = codeElem.innerHTML;

  var id = TidyCodeBlocks.length;
  TidyCodeBlocks.push(this);

	// Create an anchor around the code
  var anchor = document.createElement('a');
  anchor.setAttribute('name', 'code'+id);
  var parent = pElem.parentNode;
  parent.replaceChild(anchor, pElem);
  anchor.appendChild(pElem);

  var hiHTML;
  var tidyHTML;
  request(id,
					'code=' + escape(origCodeHTML) +
					';wordwrap=' + TidyConfig.wordwrap);

  function updateLinks() {
    while(link = linkElems.shift()) {
      dlElem.removeChild(link);
    }

    status = 0;
    if(highlight && tidy) { status = 3; }
    else if(tidy)         { status = 2; }
    else if(highlight)    { status = 1; }

    for(i=0; i<3; ++i) {
      tag = '';
      if(status == i) { tag = 'span'; }
      else { tag = 'a'; }
      link = document.createElement(tag);
      linkElems.push(link);
      dlElem.appendChild(link);
      if(status != i) {
        link.href="#code"+id;
      }

      name = '';
      switch(i) {
      case 0: name = 'plain';  break;                     
      case 1: name = 'hilite'; break;
      case 2: name = 'tidy';   break;
      }
      link.innerHTML = '['+name+']';
      link.addEventListener('click',
                            new Function('event',
                                         'TidyCodeBlocks['+id+'].setStatus('+i+
                                         ');'), true);
    }
  }

  function updateCode() {
    if(!(highlight || tidy)) {  codeElem.innerHTML = origCodeHTML; }
    else if(highlight) { codeElem.innerHTML = hiHTML; }
    else if(tidy) { codeElem.innerHTML = tidyHTML; }
  }

  function request(ownerid, content) {
    GM_xmlhttpRequest({
        method: 'POST',
        url: TidyConfig.cgiurl,
        headers: {
          "User-Agent":"PerlMonksHilight/"+PMHVersion,
            "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
            },
        data: content,
        onload: new Function("responseDetails", '          \
          if(responseDetails.status != 200) {						   \
            GM_log("Error, cgi highlighter response was "+ \
                   responseDetails.status);                \
            return;                                        \
          }                                                \
          code = TidyCodeBlocks['+ownerid+'];              \
          code.onResponse(responseDetails);')
        });
  };

	function extractHTML(id, html)
	{
		startHTML = '<div id="'+id+'">';
		stopHTML = '</div>';
		begin = html.search(startHTML);
		begin += startHTML.length;
		end = html.search(stopHTML);
		return html.substr(begin, end);
	}

  // public
  this.onResponse = function(responseDetails) {
    //GM_log("onResponse called on TidyCode "+id);
		if(responseDetails.status != 200 ||
			 responseDetails.responseText == UNPERLMSG) { return; }

		hiHTML = extractHTML('highlight', responseDetails.responseText);
		tidyHTML = extractHTML('tidy', responseDetails.responseText);
		updateLinks();
  }

  this.setStatus = function(status) {
    //GM_log('setStatus called with arg='+status);
    switch(status) {
    case 0: highlight=false;tidy=false; break;
    case 1: highlight=true; tidy=false; break;
    case 2: highlight=false;tidy=true;  break;
    }
    updateCode();
    updateLinks();
  }
}

var TidyCodeBlocks = new Array;

// All that remains of Jon Allen's PerlSyntax
// Copyright (C) 2007 Jon Allen <jj@jonallen.info>
// Should I redo everything?

var PerlSyntax     = new Object;

PerlSyntax.highlight = function() {
  var elementList = PerlSyntax.findElements(document, 'p', 'code');

  for(var i = 0; i < elementList.length; i++) {
    var element = elementList[i];
    tmp = new TidyCode(element);
  }
}

PerlSyntax.findElements = function(start, elementType,className) {
  var elementsByType  = start.getElementsByTagName(elementType);
  var elementsByClass = [];
  
  for(var i = 0; i < elementsByType.length; i++) {
    var element = elementsByType[i];
    if (!className || PerlSyntax.isClassMember(element,className)) {
      elementsByClass.push(element);
    }
  }
  
  return elementsByClass;
}

PerlSyntax.isClassMember = function(element,className) {
  var classList = element.className;
  if (classList == className) return true;
  return classList.search("\\b"+className+"\\b") != -1;
}
  
PerlSyntax.highlight();
