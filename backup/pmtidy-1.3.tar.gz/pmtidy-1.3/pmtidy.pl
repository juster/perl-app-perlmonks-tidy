#!/usr/local/bin/perl -w
# $Id: pmtidy.pl,v 1.4 2008/11/13 00:09:19 justin Exp $

=pod

=head1 NAME

pmtidy.pl - Perlmonks code block tidier CGI script

CGI backend for the Perlmonks Code Tidier Greasemonkey Script.

=head1 DESCRIPTION

A CGI script that reads in a source code file or code snippet and runs
the text through Perl::Tidy.	The code snippet is actually the html
representation of code blocks as PerlMonks formats them.	The script
is very specialized for PM's formatting and first attempts to strip
out and undo all of PM's formatting to pass in plain text to
Perl::Tidy.

Two versions of the code are returned to the browser.	 One has syntax
highlighting with color and the other is also reformatted to be nicer
on the eyes.	Both versions are returned as HTML tags and colors are
set using spans with css classes.	 The stylesheet is not sent so you
have to include that elsewhere.

The scripts attempts to keep the formatting (whitespace, linebreaks,
word wrapping) in the highlighted version as close to the original as
possible.	 The tidied version reformats/rearranges code by its nature
but will also try to wrap lines.	It fails to wrap long comments and
quoted strings.

=cut

use strict;
use warnings;
use CGI qw/:standard/;
use Perl::Tidy;
use HTML::Entities;

our $VERSION = '1.3';

use constant {
	UNPERLMSG	 => 'How very unperlish of you!',
};

=head1 FUNCTIONS

=head2 C<@foundlines = find_word_wraps( $lines )>;

=over

=item C<$lines>

Array reference to the lines of the code (HTML from PM)

=item C<@foundlines>

Array of indices into C<@$lines> where line breaks were found.

=back

Unless "Code Wrapping Off" or "Auto Code Wrapping" is selected in the
"Display" settings nodelet, PerlMonks wraps lines at a certain "Code
Wrap Length".	 Find where PerlMonks has forced line breaks in the
HTML.	 Return each line where one was found.

=cut

sub find_word_wraps {
	my $lines = shift;
	my ($joined, %found) = 0;
	for my $i (0 .. @$lines-1)
	{
		if ( $lines->[$i] =~ m|^<font color="red">\+</font>| )
		{
			$found{$i-1 - $joined++} = 1;
			# We want the previous line, remember matches get joined
			# to the previous line, hence $joined.
		}
	}
	return sort { $a <=> $b } keys %found;
}

=head2 C<insert_word_wraps( $linewraps, $lines, $linemax )>

=over

=item C<$linewraps>

Array ref to the results of find_word_wraps

=item C<$lines>

Array ref to the lines of source (HTML from perltidy)

=item C<$linemax>

The count of characters at which to wrap a line

=back

$lines will be modified in place.	 Lines will be wrapped at $linemax
characters.	 HTML tags and entities are ignored and do not affect the
line wrapping.	Lines are wrapped duplicating Perlmonks's output.

=cut

sub insert_word_wraps {
	my ($wraps, $lines, $linemax) = @_;

 LINELOOP:
	for my $wrapline ( @$wraps ) {
		my $line = \$lines->[$wrapline];
		my $charcount = 0;
		my @blocks = grep { length; } split /(<\/?span.*?>)/, $$line;

	BLOCKLOOP:
		for my $block (@blocks) {
			next BLOCKLOOP if($block =~ /^<.*>$/);
			my $blockchars = length $block;

			# HTML entities must be counted as one character.
			# But when inserting the linebreak we must skip them.
			my @entities;				 # ([ entity_start, entity_length-1 ], ...)
			while($block =~ /&#?\w+;/g) {
				my $len = $+[0] - $-[0] - 1;
				push @entities, [ $-[0], $len ];
				$blockchars -= $len;
			}

			my ($breakpos, $newchars) = (0, 0);
			while( $charcount + $blockchars > $linemax ) {
				# This is the span we are going to wordwrap
				# Breakpos = where we are looking to insert a linebreak
				# Blockchars = how many characters are left unwrapped in this block.
				# Charcount = how many characters are in the current line
				$breakpos += $linemax - $charcount;
				$blockchars -= $linemax - $charcount;

				# Skip past entities.	 Entity indices were stored with the content of
				# original string so we save entoffset to keep track of how many
				# characters we have added ourselves.
			ENTLOOP:
				while(@entities) {
					last ENTLOOP if( $entities[0][0]+$newchars > $breakpos );
					$breakpos += $entities[0][1];
					shift @entities;
				}

				my $linebreak = "\n<font color=\"red\">+</font>";
				substr $block, $breakpos, 0, $linebreak;
				$breakpos += length $linebreak;
				$newchars += length $linebreak;
				$charcount = 1;
			}
			$charcount += $blockchars;
		}#BLOCKLOOP

		$$line = join '', @blocks;
	}#LINELOOP

	1;
}

=head1 CGI PARAMETERS

=over

=item code

The html representation of the (possibly) perl code from the Perlmonks
website.	This should be URL encoded.

=item tag

The name of the tag that encloses the codeblock. This should be either
C<PRE> or C<P>.  This is case-insensitive. If tag is C<P>, this tells
the script to perform more post-processing. C<&nbsp;> entities are
inserted as well as C<< <br> >> html tags for linebreaks.

=back

=cut

my $cgi				= new CGI;
my $code			= $cgi->param('code');
my $tag				= $cgi->param('tag');

eval {
	die 'No code given' unless(defined $code);

	$code =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg; # from URI::Encode
	decode_entities($code);

	if(uc $tag eq 'P') {
		$code =~ s:\xA0: :g; # &nbsp;
		$code =~ s:<br ?/?>::g;
	}

	my ($wrapmode, $wraplen, @brokenlines) = 'off';
	if( $code =~ m!<font color="red">(.*?)</font>! ) {
		if ($1 eq '+') {
			$code =~ m#(?:^|\n)(.+?)\n<font color="red">\+</font>#;
			$wraplen = length $1;

			# Record all of the wrapped lines, to rewrap them later.
			my @lines = split /\n/, $code;
			@brokenlines = find_word_wraps( \@lines );
			$wrapmode = 'normal';
			$code =~ s:\n<font color="red">\+</font>::gm;
		}
		else {
			$code =~ m!^(.*)<font color="red">!m;
			$wraplen = length $1;
			$wrapmode = 'auto';
			my $count = $code =~
			s:<font color="red"><b><u>\xC2\xAD</u></b></font>::g;
		}
	}

	my $traillines;
	$code =~ m|(\n+)$|;
	$traillines = (length $1)-1;

	# put the perltidy.ERR file in /tmp
	chdir('/tmp') or die "could not chdir to /tmp: $!";

	# We return two versions, both are converted to html and colorized
	# But one is also tidied up (reformatted) first.
	my $errors;
	my $tidied;

	# The stderr option to perltidy does not seem to do anything!.
	# So we force it muahaha! Take that!
	open my $tmpstderr, '>', \$errors or die "open for temp STDERR: $!";
	my $oldstderr = *STDERR;
	*STDERR = $tmpstderr;
	my $tidyargs = '-sil=0';
	$tidyargs .= " -l=$wraplen" if ($wrapmode ne 'off');
	perltidy( source => \$code, destination => \$tidied, argv => $tidyargs );
	*STDERR = $oldstderr;
	close $tmpstderr;
	if( $errors ) {
		print $cgi->header;
		print UNPERLMSG;
		exit 0;
	}

	# I'm thinking errors won't happen with perltidy below if they
	# did not above...

	my $hiliteargs = '-html -pre';
	my $result;
	perltidy( source			=> \$code,
						destination => \$result,
						argv				=> $hiliteargs );
	$code = $result;
	perltidy( source			=> \$tidied,
						destination => \$result,
						argv				=> $hiliteargs );
	$tidied = $result;

	$code		=~ s|</?a.*?>||g;
	$tidied =~ s|</?a.*?>||g;
	$code		=~ s|</?pre>\n||g;
	$tidied =~ s|</?pre>\n||g;

	# For string literals, PerlTidy duplicates the spaces, putting them in front
	# of the <span> tag as well as inside.	A small bug.
	# BUT it doesn't have this bug for strings after __END__ ... sheesh
	$code		=~ s|^ +(?=<span class="q">\s+)||gm;
	$tidied =~ s|^ +(?=<span class="q">\s+)||gm;

	if( $wrapmode eq 'normal' && defined $wraplen ) {
		$code =~ m|(\n)+$|;
		my $lostnewlines = $1;
		my @codelines = split /\n/, $code;
		insert_word_wraps( \@brokenlines, \@codelines, $wraplen );
		$code = join "\n", @codelines;
		$code .= $lostnewlines;
	}

	# Match trailing to the original so we code doesn't move up.
	# If input has no trailing newline, perltidy appends one.
	# If input has 1 or more, perltidy appends only one.
	if( $traillines == 0 ) {
		chomp $code; chomp $tidied;
	}
	elsif( $traillines > 0 ) {
		$code .= "\n" x ($traillines);
		$tidied .= "\n" x ($traillines);
	}

	if( uc $tag eq 'P' ) {
		$code =~ s!(^ +| {2,})!'&nbsp; ' x (length($1)/2) .
													 (length($1)%2 ? '&nbsp;' : '')!gem;
		$tidied =~ s!(^ +| {2,})!'&nbsp; ' x (length($1)/2) .
													   (length($1)%2 ? '&nbsp;' : '')!gem;
		$code		=~ s|\n|<br />\n|g;
		$tidied =~ s|\n|<br />\n|g;
	}

	my $html = join "\n", ("<html>",
												 "<div id=\"highlight\">$code</div>",
												 "<div id=\"tidy\">$tidied</div>",
												 "</html>");
	print $cgi->header;
	print $html;
};

if($@) {
	print $cgi->header(-status => 500);
	print $@;
}

exit 0;

__END__

=pod

=head1 PERLMONKS' CODE HTML

Perlmonks can format code blocks differently depending on the Display
settings set in your Display nodelet.	 Code inside readmore tags also
have their own rules.	 Perlmonks can also wrap code to line lengths.
All of the html tags have to be stripped and lines unwrapped to keep
Perl::Tidy from choking and failing.

=head2 Code Blocks

PM has code text of two different kinds.	Code blocks and inline code.
Code blocks have their C<< <tt> >> tags surrounded by C<< <span
class='codeblock'> >> tags.	 Inline code does not.	We are only trying
to reformat the code blocks, not inline code.	 This is handled in the
Greasemonkey userscript.

=head2 Assumptions

There is always a C<< <tt class="codetext"> >> inside the C<< <pre> >> or
C<<p>> tags as described below.	 The code is inside the C<< <font> >>
tag which is inside the C<< <tt> >> tag if there is a font tag.

=head2 Quirks

There are C<< <font size="2"> >> tags everywhere.  Who knows what they
are for?  They don't seem to do anything except confuse Firefox's DOM
model.

=head2 Section-specific HTML

I first started examining the HTML of the "Seekers of Perl Wisdom".  I
found out later that some sections have slightly different formatting.

=head3 Code

Top-level posts in Code sections do not have C<< <div> >> or C<< <span> >>
tags enclosing the C<< <tt> >> codetext.  They are the same otherwise,
but these things are missing.

=head2 Display Settings

=head3 Large Code Font

PM's default behavior is to wrap code blocks with C<< <font size="-1">
>>.	 This is inside the C<< <tt> >> tags.	 If Large Code Font is
turned on these font tags are ommitted.	 This logic is taken care of
by the Greasemonkey userscript.	 The pmtidy.pl script is obvlivious to
this.	 If C< <<font>> > tags are not removed from code they will be
treated as perlcode, highlighted, and encoded as HTML entities so that
the user will see the font tags displayed around the code.

=head3 Autowrap

Autowrap breaks lines using C<< <font
color="red"><b><u>&#173;</u></b></font> >>.	 C<&#173;> is the html
entity for "small-hyphen".	This doesn't seem to display anything and
I'm not sure why it is there..?	 The small hyphen has the hex value of
0xC2AD when decoded with
L<HTML::Entities|http://search.cpan.org/~gaas/HTML-Parser-3.56/lib/HTML/Entities.pm>.
It must be removed before processing with Perltidy.

Code blocks are enclosed in C<< <p class="code"> >> tags.	 Linebreaks are
forced using C<< <br> >> tags.	&nbsp; spaces must be used for spaces.
You must alternate each "&nbsp; ", starting with 1 &nbsp;

 <p class="code">
	<span class="codeblock">
	 <tt class="codetext">
		CODE
	 </tt>
	</span>
	<span class="codeblock"><a href="...">...</a></span>
 </p>


=head3 Regular wordwrap (no Autowrap)

The default word wrapping breaks lines with C<< <font color="red">+</font> >>,
uses C<< <pre> >> tags for the topmost tag, and C<< <div> >> tags.

 <pre class="code">
	<div class="codeblock">
	 <tt class="codetext">CODE</tt>
	</div>
	<div class=""><a href="...">...</a></span>
 </pre>

=head3 Disable wordwrap

There is no wordwrapping done at all, obviously.	Code tags are
enclosed in C<< <pre class="code"> >> tags and there are no C<< <br> >> tags
needed.

 <pre class="code">
	<div class="codeblock">
	 <tt class="codetext">CODE</tt>
	</div>
	<div class=""><a href="...">...</a></span>
 </pre>

=head2 Readmore tags

Readmore tags override the above wordwrapping Display settings.	 No
wordwrapping is performed.	Code is enclosed in C<< <pre class="code"> >>
tags, always.	 There are no C<< <br> >>'s or C<&nbsp;>'s.

Font size still affects readmore tags and C<< <font size="-1"> >> may or
may not be in effect.

=head2 Summary

=head3 Hierarchy

 <(pre|p) class="code">
	 <(div|span) class="codeblock">**
		 <tt class="codetext">
			 <font size="-1">*
				 CODE
			 </font>*
		 </tt>
	 </(div|span)>**
	 <(div|span) class="embed-dl-code">
		 <font size="-1">*
			 <a>[download]</a>
		 </font>*
	 </(div|span)>
 </(pre|p)>

 *  = Not used if Large Code Font is enabled in Display nodelet.
 ** = Not used in Code section.

=head1 CREDITS

=over

=item Jon Allen

This script was inspired by and started from Jon Allen's L<AJAX perl
highlighter|http://perl.jonallen.info/projects/syntaxhighlighting>

=back

=head1 AUTHOR

juster <jrcd83 at gmail d0t com> on www.perlmonks.com

=head1 LICENSE

Copyright (c) 2008 by Justin Davis.

Released under the Artistic License.

=cut
