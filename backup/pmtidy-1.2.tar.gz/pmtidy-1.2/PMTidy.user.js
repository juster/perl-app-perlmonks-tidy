// PMTidy.user.js - PerlMonks Code Tidier
// Greasemonkey user script
// by [juster]
// -----------------------------------------------------------------------------
// Copyright (c) 2008 Justin Davis <jrcd83@gmail.com>
// Released under the Perl Artistic License.
// http://www.perlfoundation.org/legal/licenses/artistic-2_0.html
// -----------------------------------------------------------------------------
// Inspired by and started from Jon Allen's AJAX perl highlighter:
// Project website: http://perl.jonallen.info/projects/syntaxhighlighting
// -----------------------------------------------------------------------------
// $Id: PMTidy.user.js,v 1.2 2008/10/28 23:20:06 justin Exp $
// -----------------------------------------------------------------------------
// ==UserScript==
// @name           PerlMonks Code Tidier
// @namespace      http://www.perlmonks.com/?node=juster
// @description    Highlights/reformats code blocks using AJAX and perl script.
// @include        http://www.perlmonks.com/*
// ==/UserScript==

// --CONFIGURATION---------------------------------------------------------
//         cgiurl   - The url of a Perl::Tidy cgi script.
//         wordwrap - Wordwrap isn't very reliable yet, but you can try it.
//                  - 0 effectively turns off wordwrap
TidyConfig          = new Object();
TidyConfig.cgiurl   = 'http://juster.info/perl/pmtidy/pmtidy-1.2.pl';
TidyConfig.wordwrap = 0;
// ------------------------------------------------------------------------

                   // This must match the cgi script's message!
const UNPERLMSG  = "How very unperlish of you!";
const PMHVersion = "$Revision: 1.2 $";

// Insert the perltidy style classes.
GM_addStyle("\
.c  { color: #228B22;} /* comment */\n\
.cm { color: #000000;} /* comma */\n\
.co { color: #000000;} /* colon */\n\
.h  { color: #CD5555; font-weight:bold;} /* here-doc-target */\n\
.hh { color: #CD5555; font-style:italic;} /* here-doc-text */\n\
.i  { color: #00688B;} /* identifier */\n\
.j  { color: #CD5555; font-weight:bold;} /* label */\n\
.k  { color: #8B008B; font-weight:bold;} /* keyword */\n\
.m  { color: #FF0000; font-weight:bold;} /* subroutine */\n\
.n  { color: #B452CD;} /* numeric */\n\
.p  { color: #000000;} /* paren */\n\
.pd { color: #228B22; font-style:italic;} /* pod-text */\n\
.pu { color: #000000;} /* punctuation */\n\
.q  { color: #CD5555;} /* quote */\n\
.s  { color: #000000;} /* structure */\n\
.sc { color: #000000;} /* semicolon */\n\
.v  { color: #B452CD;} /* v-string */\n\
.w  { color: #000000;} /* bareword */\n\
");


function TidyCode(pElem) {
  // codeElem should be the <p class="code"> tag element
  // private
  var highlight = false;
  var tidy      = false;
  var self      = this;
  var codeElem  = PerlSyntax.findElements(pElem, 'tt', 'codetext')[0];
  var dlElem;

	if(TidyConfig.wrapMode) {
		dlElem      = PerlSyntax.findElements(pElem, 'span', 'embed-code-dl')[0];
	}
	else {
		dlElem      = PerlSyntax.findElements(pElem, 'div', 'embed-code-dl')[0];
	}

  var linkElems = new Array;
  var origCodeHTML  = codeElem.innerHTML;

  var id = TidyCodeBlocks.length;
  TidyCodeBlocks.push(this);

	// Create an anchor around the code
//   var anchor = document.createElement('a');
//   anchor.setAttribute('name', 'code'+id);
//   var parent = pElem.parentNode;
//   parent.replaceChild(anchor, pElem);
//   anchor.appendChild(pElem);

  var hiHTML;
  var tidyHTML;
  request(id,
					'code='  + escape(origCodeHTML.replace(/\+/g, '%2B')) +
					';wrap=' + TidyConfig.wordwrap +
					';lb='   + TidyConfig.wrapMode);

  function updateLinks() {
    while(link = linkElems.shift()) {
      dlElem.removeChild(link);
    }

    status = 0;
    if(highlight && tidy) { status = 3; }
    else if(tidy)         { status = 2; }
    else if(highlight)    { status = 1; }

    for(i=0; i<3; ++i) {
      tag = '';
      if(status == i) { tag = 'span'; }
      else { tag = 'a'; }
      link = document.createElement(tag);
      linkElems.push(link);
      dlElem.appendChild(link);

      name = '';
      switch(i) {
      case 0: name = 'plain';  desc = "Original formatting"; break;
      case 1: name = 'hilite'; desc = "Color highlight";     break;
      case 2: name = 'tidy';   desc = "Color and reformat";  break;
      }

      if(status != i) {
        link.href="javascript:true;";
				link.addEventListener('click',
															new Function('event',
																					 'TidyCodeBlocks['+id+'].setStatus('+i+
																					 ');'), true);
// 				link.addEventListener('mouseover',
// 															function(event) {
// 																//alert("WTF");
// 																self.status = desc;
// 																return true;
// 															},
// 															false);
      }


      link.innerHTML = '['+name+']';
    }
  }

  function updateCode() {
		newHTML = '';
    if(!(highlight || tidy)) {  newHTML = origCodeHTML; }
    else if(highlight) { newHTML = hiHTML; }
    else if(tidy) { newHTML = tidyHTML; }

		GM_log(newHTML);
		// innerHTML added tags (!?!) so I will try this approach
		// removing all child nodes first seems to stop this
		child = codeElem.firstChild;
		while(child) {
			next = child.nextSibling;
			codeElem.removeChild(child);
			child = next;
		}
		codeElem.innerHTML = newHTML;

		return 1;
  }

  function request(ownerid, content) {
    GM_xmlhttpRequest({
        method: 'POST',
        url: TidyConfig.cgiurl,
        headers: {
          "User-Agent":"PerlMonksHilight/"+PMHVersion,
            "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
            },
        data: content,
        onload: new Function("responseDetails", '          \
          if(responseDetails.status != 200) {						   \
            GM_log("Error, cgi highlighter response was "+ \
                   responseDetails.status);                \
            return;                                        \
          }                                                \
          code = TidyCodeBlocks['+ownerid+'];              \
          code.onResponse(responseDetails);')
        });
  };

	function extractHTML(id, html)
	{
		startHTML = '<div id="'+id+'">';
		stopHTML = '</div>';
		begin = html.search(startHTML);
		if(begin == -1) return 0;
		begin += startHTML.length;
		html = html.substr(begin);
		end = html.search(stopHTML);
		if(end == -1) return 0;
		return html.substr(0, end);
	}

  // public
  this.onResponse = function(responseDetails) {
    //GM_log("onResponse called on TidyCode "+id);
		if(responseDetails.status != 200 ||
			 responseDetails.responseText == UNPERLMSG) { return; }

		hiExtract = extractHTML('highlight', responseDetails.responseText);
		tidyExtract = extractHTML('tidy', responseDetails.responseText);
		//GM_log(hiExtract);
		//GM_log(tidyExtract);
		if(!(hiExtract && tidyExtract)) {
			GM_log("Malformed response from perltidy.pl! Script borked?");
			return;
		}
		hiHTML = hiExtract;
		tidyHTML = tidyExtract;
		updateLinks();
  }

  this.setStatus = function(status) {
    //GM_log('setStatus called with arg='+status);
    switch(status) {
    case 0: highlight=false;tidy=false; break;
    case 1: highlight=true; tidy=false; break;
    case 2: highlight=false;tidy=true;  break;
    }
    updateCode();
    updateLinks();
  }
}

var TidyCodeBlocks = new Array;

// All that remains of Jon Allen's PerlSyntax
// Copyright (C) 2007 Jon Allen <jj@jonallen.info>
// Should I redo everything?

var PerlSyntax     = new Object;

PerlSyntax.highlight = function() {
	elementList = PerlSyntax.findElements(document, 'pre', 'code');
	if(!elementList.length) {
		elementList = PerlSyntax.findElements(document, 'p', 'code');
		if(!elementList.length) {
			GM_log('Could not find any <pre class="code"> or <p class="code"> '+
						 'code blocks to tidy');
			return;
		}
		TidyConfig.wrapMode = 1;
	}
	else {
		TidyConfig.wrapMode = 0;
	}
	// PM uses different tags depending on if you turn
	// on Code Wrapping in Display settings

  for(i = 0; i < elementList.length; i++) {
    element = elementList[i];
    tmp = new TidyCode(element);
  }
}

PerlSyntax.findElements = function(start, elementType,className) {
  var elementsByType  = start.getElementsByTagName(elementType);
  var elementsByClass = [];
  
  for(var i = 0; i < elementsByType.length; i++) {
    var element = elementsByType[i];
    if (!className || PerlSyntax.isClassMember(element,className)) {
      elementsByClass.push(element);
    }
  }
  
  return elementsByClass;
}

PerlSyntax.isClassMember = function(element,className) {
  var classList = element.className;
  if (classList == className) return true;
  return classList.search("\\b"+className+"\\b") != -1;
}

PerlSyntax.highlight();
