#!/usr/local/bin/perl -w

# CGI backend for the Perlmonks Code Tidier Greasemonkey Script
# by [juster]
#
# Copyright (c) 2008 Justin Davis <jrcd83@gmail.com>
# Released under the Perl Artistic License.
# http://www.perlfoundation.org/legal/licenses/artistic-2_0.html
#
# Inspired by and started from Jon Allen's AJAX perl highlighter:
# Project website: http://perl.jonallen.info/projects/syntaxhighlighting
#
# $Id: pmtidy.pl,v 1.3 2008/11/08 04:07:43 justin Exp $

use strict;
use warnings;
use CGI qw/:standard/;
use Perl::Tidy;
use HTML::Entities;
use XML::Simple;

our $VERSION = '1.3';

use constant {
  UNPERLMSG  => 'How very unperlish of you!',
};

my $cgi       = new CGI;
my $code      = $cgi->param('code');
my $wordwrap  = $cgi->param('wrap');
my $wrapmode  = $cgi->param('lb');
my $tabsize   = $cgi->param('tabsize');

eval {
  die 'No code given' unless(defined $code);
  $wordwrap = 80 unless(defined $wordwrap);
  $code =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg; # from URI::Encode
  decode_entities($code);

	$code =~ s|<font\ color="red"><b>
						 <u>\xC2\xAD</u>
						 </b></font>||gxs if($wrapmode);
  $code =~ s/\xA0/ /g; # &nbsp;
  $code =~ s|<br\s*/?>||g;

	my $traillines;
	$code =~ m|(\n+)$|;
	$traillines = (length $1)-1;

  # put the perltidy.ERR file in /tmp
  chdir('/usr/home/juster/logs') or die "could not chdir to /tmp: $!";

  # We return two versions, both are converted to html and colorized
  # But one is also tidied up (reformatted) first.
  my $errors;
  my $tidied;

  # The stderr option to perltidy does not seem to do anything!.
  # So we force it muahaha! Take that!
  open my $tmpstderr, '>', \$errors or die "open for temp STDERR: $!";
  my $oldstderr = *STDERR;
  *STDERR = $tmpstderr;
	my $tidyargs = '-sil=0';
	$tidyargs .= " -l=$wordwrap" if ($wordwrap);
  perltidy( source => \$code, destination => \$tidied, argv => $tidyargs );
  *STDERR = $oldstderr;
  close $tmpstderr;
  if( $errors ) {
    print $cgi->header;
    print UNPERLMSG;
    exit 0;
  }

  # I'm thinking errors won't happen with perltidy below if they
  # did not above...

  # Wordwrap is screwy.  It works above in the tidied verson
	# but no reformatting is done with the highlight version (of course).
	# So I should replace PerlTidy's wordwrap with my own version
	# that matches perlmonks

  my $hiliteargs = '-html -pre';
  $hiliteargs .= " -i=$tabsize" if(defined $tabsize);

  my $result;
  perltidy( source      => \$code,
            destination => \$result,
            argv        => $hiliteargs );
  $code = $result;
  perltidy( source      => \$tidied,
            destination => \$result,
            argv        => $hiliteargs );
  $tidied = $result;

  $code   =~ s|</?a.*?>||g;
  $code   =~ s|</?pre>\n||g;
  $tidied =~ s|</?pre>\n||g;

	# Match trailing to the original so we code doesn't move up.
	# Keep in mind PerlTidy adds a trailing newline on its own.
	if($traillines > 0) {
		$code .= "\n" x ($traillines-1);
	}
	else { chomp $code;	}

# 	open my $errlog, '>>', '/usr/home/juster/logs/pmtidy.log';
#  	print $errlog "\n***\nwrapmode = $wrapmode\n$code\n";
# 	close $errlog;

	# For string literals, PerlTidy duplicates the spaces, putting them in front
	# of the <span> tag as well as inside.  A small bug.
	# BUT it doesn't have this bug for strings after __END__ ... sheesh
	$code   =~ s|^ +(?=<span class="q">\s+)||gm;
	$tidied =~ s|^ +(?=<span class="q">\s+)||gm;

	if($wrapmode) {
		$code =~ s!(^ +| {2,})!'&nbsp; ' x (length($1)/2) .
		                         (length($1)%2 ? '&nbsp;' : '')!gem;
		$tidied =~ s!(^ +| {2,})!'&nbsp; ' x (length($1)/2) .
		                         (length($1)%2 ? '&nbsp;' : '')!gem;
		$code   =~ s|$|<br />|mg;
		$tidied =~ s|$|<br />|mg;
	}
  my $html = join "\n", ("<html>",
                         "<div id=\"highlight\">$code</div>",
                         "<div id=\"tidy\">$tidied</div>",
                         "</html>");
  print $cgi->header;
  print $html;
};

if($@) {
  print $cgi->header(-status => 500);
  #die "$0: $@";
}

exit 0;

